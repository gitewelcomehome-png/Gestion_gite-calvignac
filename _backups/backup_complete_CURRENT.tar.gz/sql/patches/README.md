# 🩹 Patches Code JavaScript

> Patches appliqués au code après nettoyage BDD (23/01/2026)

## Fichiers

### NETTOYAGE_CODE_JS_PATCHES.sql
Requêtes SQL documentant les changements dans le code JavaScript

### PATCH_NETTOYAGE_CODE_JS_23JAN2026.md
Documentation détaillée des 34 références désactivées dans 6 fichiers JS

---

**Contexte** : 7 tables supprimées → code JS mis à jour pour éviter erreurs 404

**Fichiers modifiés** :
- js/dashboard.js
- js/fiches-clients.js
- js/fiscalite-v2.js
- js/femme-menage.js
- js/fiche-client-app.js
- js/menage.js
