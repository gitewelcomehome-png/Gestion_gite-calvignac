# 🔧 Correctifs SQL

> Scripts de correction bugs et problèmes techniques

## Fichiers

### fix_cleaning_schedule_rls.sql
Correction des policies RLS (Row Level Security) sur la table `cleaning_schedule`

### fix_postgrest_infos_gites.sql
Correction des permissions PostgREST pour la table `infos_gites`

---

**Usage** : Exécuter dans le SQL Editor de Supabase si problème détecté
